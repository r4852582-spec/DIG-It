# server.py
import socket
import threading
import json

HOST = '0.0.0.0'  # слушаем все интерфейсы (Wi-Fi, Ethernet, localhost)
PORT = 12345

clients = []  # список сокетов подключённых клиентов
lock = threading.Lock()

def broadcast(message, sender_socket=None):
    """Отправляет сообщение всем клиентам, кроме отправителя (если указан)."""
    with lock:
        for client in clients[:]:
            if client != sender_socket:
                try:
                    client.sendall(message)
                except:
                    # если клиент отключился, удаляем его
                    clients.remove(client)

def client_handler(conn, addr):
    print(f"[+] Подключён {addr}")
    with lock:
        clients.append(conn)

    try:
        buffer = ""
        while True:
            data = conn.recv(1024)
            if not data:
                break
            buffer += data.decode('utf-8')
            while '\n' in buffer:
                line, buffer = buffer.split('\n', 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    print(f"[{addr}] Получено: {msg}")
                    # Рассылаем всем (включая отправителя, чтобы админ тоже видел свои команды)
                    broadcast((json.dumps(msg, ensure_ascii=False) + '\n').encode('utf-8'), sender_socket=None)
                except json.JSONDecodeError:
                    print(f"[{addr}] Некорректный JSON: {line}")
    except ConnectionResetError:
        pass
    finally:
        print(f"[-] Отключён {addr}")
        with lock:
            if conn in clients:
                clients.remove(conn)
        conn.close()

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"[*] Сервер запущен на {HOST}:{PORT}")
    print(f"[*] Локальный IP для подключений: 10.59.69.60 (или проверьте ipconfig)")

    try:
        while True:
            conn, addr = server.accept()
            threading.Thread(target=client_handler, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[*] Сервер остановлен.")
    finally:
        server.close()

if __name__ == "__main__":
    main()