# admin.py (подключается к 10.59.69.60:12345)
import pygame
import socket
import json
import threading
import queue
import sys

# ------------------------------
# Настройки окна админа
# ------------------------------
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 300
FPS = 30

BG_COLOR = (50, 50, 50)
TEXT_COLOR = (255, 255, 255)
BUTTON_COLOR = (100, 100, 100)
BUTTON_HOVER = (150, 150, 150)
INPUT_COLOR = (200, 200, 200)

# ------------------------------
# Сетевой клиент (аналог game.py)
# ------------------------------
class AdminNetworkClient:
    def __init__(self, host='10.59.69.60', port=12345):
        self.host = host
        self.port = port
        self.sock = None
        self.connected = False
        self.command_queue = queue.Queue()
        self._stop = False
        self._thread = None

    def connect(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.host, self.port))
            self.connected = True
            self._thread = threading.Thread(target=self._receive_loop, daemon=True)
            self._thread.start()
            print(f"[Админ] Подключено к серверу {self.host}:{self.port}")
        except Exception as e:
            print(f"[Админ] Не удалось подключиться: {e}")
            self.connected = False

    def _receive_loop(self):
        buffer = ""
        while not self._stop:
            try:
                data = self.sock.recv(1024)
                if not data:
                    break
                buffer += data.decode('utf-8')
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        self.command_queue.put(msg)
                    except:
                        pass
            except:
                break
        self.connected = False
        print("[Админ] Соединение потеряно")

    def send(self, msg_dict):
        if not self.connected:
            return
        try:
            data = (json.dumps(msg_dict, ensure_ascii=False) + '\n').encode('utf-8')
            self.sock.sendall(data)
        except:
            self.connected = False

    def close(self):
        self._stop = True
        if self.sock:
            self.sock.close()
        self.connected = False

# ------------------------------
# Графический интерфейс админа
# ------------------------------
class AdminApp:
    def __init__(self):
        self.network = AdminNetworkClient()
        self.network.connect()

        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Админ-панель раскопок")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 24)

        # Поля ввода (храним текст и активность)
        self.money_input = "100"
        self.msg_input = "Привет, копатель!"
        self.active_input = None  # 'money' или 'message'

        self.buttons = {
            "send_money": pygame.Rect(250, 40, 120, 30),
            "send_msg":   pygame.Rect(250, 120, 120, 30),
        }
        self.input_rects = {
            "money": pygame.Rect(30, 40, 200, 30),
            "message": pygame.Rect(30, 120, 200, 30),
        }

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    # Проверяем нажатия на поля ввода
                    if self.input_rects["money"].collidepoint(pos):
                        self.active_input = "money"
                    elif self.input_rects["message"].collidepoint(pos):
                        self.active_input = "message"
                    else:
                        self.active_input = None

                    # Проверяем кнопки
                    if self.buttons["send_money"].collidepoint(pos):
                        try:
                            amount = int(self.money_input)
                            self.network.send({"action": "add_money", "amount": amount})
                            print(f"Отправлено: +${amount}")
                        except ValueError:
                            print("Некорректная сумма")
                    elif self.buttons["send_msg"].collidepoint(pos):
                        text = self.msg_input.strip()
                        if text:
                            self.network.send({"action": "show_message", "text": text})
                            print(f"Отправлено сообщение: {text}")

                elif event.type == pygame.KEYDOWN:
                    if self.active_input == "money":
                        if event.key == pygame.K_BACKSPACE:
                            self.money_input = self.money_input[:-1]
                        elif event.unicode.isdigit():
                            self.money_input += event.unicode
                    elif self.active_input == "message":
                        if event.key == pygame.K_BACKSPACE:
                            self.msg_input = self.msg_input[:-1]
                        elif event.unicode:
                            self.msg_input += event.unicode

            # Отрисовка
            self.screen.fill(BG_COLOR)
            # Поле "Деньги"
            pygame.draw.rect(self.screen, INPUT_COLOR, self.input_rects["money"], 2)
            money_surf = self.font.render(f"Сумма: {self.money_input}", True, TEXT_COLOR)
            self.screen.blit(money_surf, (self.input_rects["money"].x + 5, self.input_rects["money"].y + 5))
            # Поле "Сообщение"
            pygame.draw.rect(self.screen, INPUT_COLOR, self.input_rects["message"], 2)
            msg_surf = self.font.render(f"Текст: {self.msg_input}", True, TEXT_COLOR)
            self.screen.blit(msg_surf, (self.input_rects["message"].x + 5, self.input_rects["message"].y + 5))
            # Кнопки
            for name, rect in self.buttons.items():
                color = BUTTON_HOVER if rect.collidepoint(pygame.mouse.get_pos()) else BUTTON_COLOR
                pygame.draw.rect(self.screen, color, rect)
                label = "Выдать деньги" if name == "send_money" else "Отправить"
                btn_surf = self.font.render(label, True, TEXT_COLOR)
                self.screen.blit(btn_surf, (rect.x + 5, rect.y + 5))

            # Статус соединения
            status = "Подключено" if self.network.connected else "Нет связи"
            status_surf = self.font.render(status, True, (0, 255, 0) if self.network.connected else (255, 0, 0))
            self.screen.blit(status_surf, (10, 250))

            pygame.display.flip()

        self.network.close()
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    AdminApp().run()