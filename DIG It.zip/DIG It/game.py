# game.py (с подключением к 10.59.69.60:12345)
import pygame
import random
import sys
import os
import socket
import threading
import json
import queue

# ------------------------------
# Настройки игры
# ------------------------------
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
COOLDOWN_MS = 700          # задержка между копками
MESSAGE_DURATION_MS = 2000 # длительность сообщения

# Цвета
BG_COLOR = (40, 30, 20)
PANEL_COLOR = (70, 50, 30)
BUTTON_COLOR = (120, 80, 40)
BUTTON_HOVER = (160, 110, 50)
BUTTON_DISABLED = (80, 60, 30)
TEXT_COLOR = (255, 220, 180)
ACCENT_COLOR = (220, 180, 80)
WHITE = (255, 255, 255)

# ------------------------------
# Предметы
# ------------------------------
class Item:
    def __init__(self, name, icon, price, weight=1):
        self.name = name
        self.icon = icon
        self.price = price
        self.weight = weight

ITEMS = [
    Item("Камень", "[К]", 3, 5),
    Item("Кость", "[Кос]", 5, 4),
    Item("Древняя монета", "[Мон]", 12, 2),
    Item("Осколок керамики", "[Оск]", 8, 3),
    Item("Золотой самородок", "[Зол]", 25, 1),
]

ITEMS_BY_NAME = {item.name: item for item in ITEMS}

def get_random_item():
    items, weights = zip(*[(item, item.weight) for item in ITEMS])
    return random.choices(items, weights=weights, k=1)[0]

# ------------------------------
# Лопата и прокачка
# ------------------------------
class Shovel:
    def __init__(self):
        self.level = 1
        self.digs_needed = {1: 5, 2: 4, 3: 3, 4: 2, 5: 1}
        self.upgrade_cost = {2: 100, 3: 250, 4: 600, 5: 1500}

    def get_digs_needed(self):
        return self.digs_needed[self.level]

    def next_level_info(self):
        if self.level < 5:
            nxt = self.level + 1
            return nxt, self.upgrade_cost[nxt], self.digs_needed[nxt]
        return None

    def upgrade(self, money):
        info = self.next_level_info()
        if info is None:
            return 0
        nxt, cost, _ = info
        if money >= cost:
            self.level = nxt
            return cost
        return 0

# ------------------------------
# Инвентарь
# ------------------------------
class Inventory:
    def __init__(self):
        self.items = {}

    def add_item(self, item_name, count=1):
        self.items[item_name] = self.items.get(item_name, 0) + count

    def remove_item(self, item_name, count=1):
        if item_name in self.items:
            self.items[item_name] -= count
            if self.items[item_name] <= 0:
                del self.items[item_name]

    def get_all_items(self):
        return list(self.items.items())

    def total_value(self):
        total = 0
        for name, cnt in self.items.items():
            item = ITEMS_BY_NAME.get(name)
            if item:
                total += item.price * cnt
        return total

    def clear(self):
        self.items.clear()

# ------------------------------
# Частицы (анимация грязи)
# ------------------------------
class Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = random.uniform(-3, 3)
        self.vy = random.uniform(-6, -2)
        self.lifetime = random.uniform(0.5, 0.9)
        self.max_lifetime = self.lifetime
        self.size = random.randint(3, 6)
        self.color = (139, 90, 43)
        self.gravity = 200

    def update(self, dt):
        self.lifetime -= dt
        if self.lifetime <= 0:
            return False
        self.vy += self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        return True

    def draw(self, surface):
        alpha = int(255 * (self.lifetime / self.max_lifetime))
        s = pygame.Surface((self.size*2, self.size*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.color, alpha),
                           (self.size, self.size), self.size)
        surface.blit(s, (self.x - self.size, self.y - self.size))

# ------------------------------
# Сетевой клиент
# ------------------------------
class NetworkClient:
    def __init__(self, host='10.59.69.60', port=12345):  # <-- IP вашего ПК в локальной сети
        self.host = host
        self.port = port
        self.sock = None
        self.connected = False
        self.command_queue = queue.Queue()
        self._stop = False
        self._thread = None

    def connect(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.host, self.port))
            self.connected = True
            self._thread = threading.Thread(target=self._receive_loop, daemon=True)
            self._thread.start()
            print(f"[Сеть] Подключено к серверу {self.host}:{self.port}")
        except Exception as e:
            print(f"[Сеть] Не удалось подключиться: {e}")
            self.connected = False

    def _receive_loop(self):
        buffer = ""
        while not self._stop:
            try:
                data = self.sock.recv(1024)
                if not data:
                    break
                buffer += data.decode('utf-8')
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        self.command_queue.put(msg)
                    except json.JSONDecodeError:
                        pass
            except:
                break
        self.connected = False
        print("[Сеть] Соединение потеряно")

    def send(self, msg_dict):
        if not self.connected:
            return
        try:
            data = (json.dumps(msg_dict, ensure_ascii=False) + '\n').encode('utf-8')
            self.sock.sendall(data)
        except:
            self.connected = False

    def close(self):
        self._stop = True
        if self.sock:
            self.sock.close()
        self.connected = False

# ------------------------------
# Безопасная загрузка шрифта
# ------------------------------
def load_font(size):
    candidates = ["arial", "freesans", "liberationsans", "dejavusans"]
    for name in candidates:
        try:
            font = pygame.font.SysFont(name, size)
            return font
        except:
            continue
    return pygame.font.Font(None, size)

# ------------------------------
# Подбор шрифта под кнопку
# ------------------------------
def fit_font(text, max_width, start_size, min_size=10):
    size = start_size
    while size >= min_size:
        font = load_font(size)
        w, _ = font.size(text)
        if w <= max_width - 10:
            return font
        size -= 2
    return load_font(min_size)

# ------------------------------
# Отрисовка кнопок
# ------------------------------
def draw_button(surface, rect, text, default_size, bg_color, text_color=TEXT_COLOR,
                border_radius=8, hover=False, disabled=False):
    if disabled:
        color = BUTTON_DISABLED
    elif hover:
        color = BUTTON_HOVER
    else:
        color = bg_color
    pygame.draw.rect(surface, color, rect, border_radius=border_radius)
    pygame.draw.rect(surface, ACCENT_COLOR, rect, 2, border_radius=border_radius)
    font = fit_font(text, rect.width, default_size)
    text_surf = font.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    surface.blit(text_surf, text_rect)

# ------------------------------
# Основной игровой класс
# ------------------------------
class Game:
    def __init__(self, network_client=None):
        self.money = 0
        self.shovel = Shovel()
        self.inventory = Inventory()
        self.state = "dig"

        self.digs_done = 0
        self.last_dig_time = 0

        self.message = None
        self.message_time = 0

        self.font_large = load_font(36)
        self.font_medium = load_font(28)
        self.font_small = load_font(22)

        self.buttons = {}
        self.particles = []

        self.network = network_client

        # Загрузка звуков копки (mp3)
        self.dig_sounds = []
        sound_dir = r"C:\Users\Рамин\Desktop\DIG It\sounds"
        for fname in ["cop1.mp3", "cop2.mp3"]:
            path = os.path.join(sound_dir, fname)
            try:
                snd = pygame.mixer.Sound(path)
                self.dig_sounds.append(snd)
            except Exception as e:
                # Если mp3 не грузится, пробуем wav
                wav_path = os.path.join(sound_dir, fname.replace(".mp3", ".wav"))
                try:
                    snd = pygame.mixer.Sound(wav_path)
                    self.dig_sounds.append(snd)
                except:
                    pass

    def process_network_commands(self):
        if not self.network:
            return
        while not self.network.command_queue.empty():
            try:
                cmd = self.network.command_queue.get_nowait()
                action = cmd.get("action")
                if action == "add_money":
                    amount = cmd.get("amount", 0)
                    self.money += amount
                    self.message = f"Админ: +${amount}"
                    self.message_time = pygame.time.get_ticks()
                elif action == "show_message":
                    text = cmd.get("text", "")
                    self.message = text
                    self.message_time = pygame.time.get_ticks()
            except queue.Empty:
                break

    def try_dig(self):
        now = pygame.time.get_ticks()
        if now - self.last_dig_time < COOLDOWN_MS:
            return
        self.last_dig_time = now
        self.digs_done += 1

        if self.dig_sounds:
            random.choice(self.dig_sounds).play()

        dig_cx = SCREEN_WIDTH // 2
        dig_cy = 335
        for _ in range(12):
            self.particles.append(Particle(dig_cx, dig_cy))

        needed = self.shovel.get_digs_needed()
        if self.digs_done >= needed:
            item = get_random_item()
            self.inventory.add_item(item.name)
            self.message = f"{item.icon} {item.name} найден! (+${item.price})"
            self.message_time = now
            self.digs_done = 0

    def update(self, dt):
        self.process_network_commands()
        now = pygame.time.get_ticks()
        if self.message and now - self.message_time > MESSAGE_DURATION_MS:
            self.message = None
        self.particles = [p for p in self.particles if p.update(dt)]

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._handle_click(event.pos)

    def _handle_click(self, pos):
        if self.state == "dig":
            self._handle_dig_click(pos)
        elif self.state == "inventory":
            self._handle_inventory_click(pos)
        elif self.state == "shop":
            self._handle_shop_click(pos)

    def _handle_dig_click(self, pos):
        if "dig" in self.buttons and self.buttons["dig"].collidepoint(pos):
            self.try_dig()
        if "to_inv" in self.buttons and self.buttons["to_inv"].collidepoint(pos):
            self.state = "inventory"
        if "to_shop" in self.buttons and self.buttons["to_shop"].collidepoint(pos):
            self.state = "shop"

    def _handle_inventory_click(self, pos):
        for name, cnt in self.inventory.get_all_items():
            btn_key = f"sell_{name}"
            if btn_key in self.buttons and self.buttons[btn_key].collidepoint(pos):
                item = ITEMS_BY_NAME.get(name)
                if item:
                    self.money += item.price
                    self.inventory.remove_item(name)
                    self.message = f"Продан {item.icon} {name} за ${item.price}"
                    self.message_time = pygame.time.get_ticks()
                return

        if "sell_all" in self.buttons and self.buttons["sell_all"].collidepoint(pos):
            total = self.inventory.total_value()
            if total > 0:
                self.money += total
                self.inventory.clear()
                self.message = f"Продано всё! +${total}"
                self.message_time = pygame.time.get_ticks()

        if "back_inv" in self.buttons and self.buttons["back_inv"].collidepoint(pos):
            self.state = "dig"

    def _handle_shop_click(self, pos):
        info = self.shovel.next_level_info()
        if info and "upgrade" in self.buttons and self.buttons["upgrade"].collidepoint(pos):
            cost = self.shovel.upgrade(self.money)
            if cost > 0:
                self.money -= cost
                self.message = f"Лопата улучшена до уровня {self.shovel.level}!"
                self.message_time = pygame.time.get_ticks()

        if "back_shop" in self.buttons and self.buttons["back_shop"].collidepoint(pos):
            self.state = "dig"

    def draw(self, surface):
        surface.fill(BG_COLOR)
        if self.state == "dig":
            self._draw_dig_screen(surface)
        elif self.state == "inventory":
            self._draw_inventory_screen(surface)
        elif self.state == "shop":
            self._draw_shop_screen(surface)

        for p in self.particles:
            p.draw(surface)

        money_text = self.font_medium.render(f"$ {self.money}", True, TEXT_COLOR)
        surface.blit(money_text, (20, 10))

        if self.message:
            msg_surf = self.font_medium.render(self.message, True, ACCENT_COLOR)
            msg_rect = msg_surf.get_rect(center=(SCREEN_WIDTH // 2, 50))
            surface.blit(msg_surf, msg_rect)

    def _draw_dig_screen(self, surface):
        self.buttons.clear()
        title = self.font_large.render("=== РАСКОПКИ ===", True, TEXT_COLOR)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 100))

        lvl_text = f"Лопата ур. {self.shovel.level}"
        needed = self.shovel.get_digs_needed()
        info_text = f"Копков до находки: {needed}"
        lvl_surf = self.font_small.render(lvl_text, True, TEXT_COLOR)
        info_surf = self.font_small.render(info_text, True, TEXT_COLOR)
        surface.blit(lvl_surf, (SCREEN_WIDTH // 2 - lvl_surf.get_width() // 2, 160))
        surface.blit(info_surf, (SCREEN_WIDTH // 2 - info_surf.get_width() // 2, 190))

        progress_text = f"Прогресс: {self.digs_done} / {needed}"
        prog_surf = self.font_medium.render(progress_text, True, ACCENT_COLOR)
        surface.blit(prog_surf, (SCREEN_WIDTH // 2 - prog_surf.get_width() // 2, 240))

        dig_rect = pygame.Rect(SCREEN_WIDTH // 2 - 120, 300, 240, 70)
        self.buttons["dig"] = dig_rect

        now = pygame.time.get_ticks()
        on_cooldown = now - self.last_dig_time < COOLDOWN_MS
        mouse_pos = pygame.mouse.get_pos()
        hover = dig_rect.collidepoint(mouse_pos) and not on_cooldown
        draw_button(surface, dig_rect, "КОПАТЬ", 36, BUTTON_COLOR, TEXT_COLOR,
                    hover=hover, disabled=on_cooldown)

        inv_rect = pygame.Rect(130, 500, 220, 50)
        shop_rect = pygame.Rect(450, 500, 220, 50)
        self.buttons["to_inv"] = inv_rect
        self.buttons["to_shop"] = shop_rect
        draw_button(surface, inv_rect, "Инвентарь", 24, BUTTON_COLOR,
                    hover=inv_rect.collidepoint(mouse_pos))
        draw_button(surface, shop_rect, "Магазин", 24, BUTTON_COLOR,
                    hover=shop_rect.collidepoint(mouse_pos))

    def _draw_inventory_screen(self, surface):
        self.buttons.clear()
        title = self.font_large.render("ИНВЕНТАРЬ", True, TEXT_COLOR)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 40))

        items = self.inventory.get_all_items()
        y_start = 100
        mouse_pos = pygame.mouse.get_pos()

        if not items:
            empty = self.font_medium.render("Инвентарь пуст", True, TEXT_COLOR)
            surface.blit(empty, (SCREEN_WIDTH // 2 - empty.get_width() // 2, 250))
        else:
            for i, (name, count) in enumerate(items):
                item = ITEMS_BY_NAME.get(name)
                if not item:
                    continue
                y = y_start + i * 80
                line = f"{item.icon} {name}  x{count}"
                line_surf = self.font_small.render(line, True, TEXT_COLOR)
                surface.blit(line_surf, (100, y + 5))
                price_line = f"Цена: ${item.price}"
                price_surf = self.font_small.render(price_line, True, TEXT_COLOR)
                surface.blit(price_surf, (100, y + 35))
                sell_rect = pygame.Rect(550, y + 15, 140, 40)
                btn_key = f"sell_{name}"
                self.buttons[btn_key] = sell_rect
                draw_button(surface, sell_rect, "Продать", 22, BUTTON_COLOR,
                            hover=sell_rect.collidepoint(mouse_pos))

        sell_all_rect = pygame.Rect(270, 460, 260, 50)
        self.buttons["sell_all"] = sell_all_rect
        total_val = self.inventory.total_value()
        sell_text = f"Продать всё (${total_val})"
        draw_button(surface, sell_all_rect, sell_text, 24, BUTTON_COLOR,
                    hover=sell_all_rect.collidepoint(mouse_pos))

        back_rect = pygame.Rect(50, 530, 150, 50)
        self.buttons["back_inv"] = back_rect
        draw_button(surface, back_rect, "<- Назад", 24, BUTTON_COLOR,
                    hover=back_rect.collidepoint(mouse_pos))

    def _draw_shop_screen(self, surface):
        self.buttons.clear()
        title = self.font_large.render("МАГАЗИН", True, TEXT_COLOR)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 40))

        cur_text = f"Лопата ур. {self.shovel.level} (копков: {self.shovel.get_digs_needed()})"
        cur_surf = self.font_medium.render(cur_text, True, TEXT_COLOR)
        surface.blit(cur_surf, (SCREEN_WIDTH // 2 - cur_surf.get_width() // 2, 120))

        info = self.shovel.next_level_info()
        mouse_pos = pygame.mouse.get_pos()

        if info is None:
            max_text = self.font_medium.render("Лопата макс. уровня!", True, ACCENT_COLOR)
            surface.blit(max_text, (SCREEN_WIDTH // 2 - max_text.get_width() // 2, 250))
        else:
            nxt_lvl, cost, digs = info
            upgrade_text = f"Уровень {nxt_lvl}: нужно {digs} копков, цена ${cost}"
            upg_surf = self.font_small.render(upgrade_text, True, TEXT_COLOR)
            surface.blit(upg_surf, (SCREEN_WIDTH // 2 - upg_surf.get_width() // 2, 220))

            upgrade_rect = pygame.Rect(SCREEN_WIDTH // 2 - 140, 280, 280, 60)
            self.buttons["upgrade"] = upgrade_rect
            can_afford = self.money >= cost
            draw_button(surface, upgrade_rect, f"Улучшить за ${cost}", 22, BUTTON_COLOR,
                        hover=upgrade_rect.collidepoint(mouse_pos) and can_afford,
                        disabled=not can_afford)
            if not can_afford:
                hint = self.font_small.render("Недостаточно денег", True, ACCENT_COLOR)
                surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 350))

        back_rect = pygame.Rect(50, 530, 150, 50)
        self.buttons["back_shop"] = back_rect
        draw_button(surface, back_rect, "<- Назад", 24, BUTTON_COLOR,
                    hover=back_rect.collidepoint(mouse_pos))

# ------------------------------
# Запуск игры
# ------------------------------
def main():
    pygame.init()
    try:
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error as e:
        print(f"Ошибка при создании окна: {e}")
        sys.exit()

    pygame.display.set_caption("Раскопки (сеть)")
    clock = pygame.time.Clock()

    # Подключение к серверу
    network = NetworkClient()  # по умолчанию 10.59.69.60:12345
    network.connect()

    game = Game(network)

    running = True
    while running:
        dt_ms = clock.tick(FPS)
        dt_sec = dt_ms / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            game.handle_event(event)

        game.update(dt_sec)
        game.draw(screen)
        pygame.display.flip()

    if network:
        network.close()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()